export const FontColors = {
  white: '#ffffff',
  cyan: '#1affc2'
};
