const Colors = [
  // Cyan
  {
    r: 0,
    g: 255,
    b: 210
  },
  // Yellow
  {
    r: 249,
    g: 213,
    b: 35
  },
  // Purple
  {
    r: 185,
    g: 33,
    b: 231
  },
  // Red
  {
    r: 238,
    g: 21,
    b: 41
  },
  // Pink
  {
    r: 238,
    g: 8,
    b: 98
  }
];

export { Colors };
