export const Fonts = {
  brandon: {
    name: 'Brandon_blk',
    src: '/assets/fonts/BrandonGrotesque-Black.woff'
  },
  brandonLgt: {
    name: 'Brandon_lgt',
    src: '/assets/fonts/BrandonGrotesque-Light.woff'
  }
};
