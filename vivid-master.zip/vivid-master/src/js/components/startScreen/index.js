import {
  StartScreen
} from './startScreen';

export default StartScreen;
